package Classes;

public class Person {
	
	private String name;
	
	public Person()
	{
		name="";
	}
	
	public String getName(String person_name)
	{
		return name=person_name; //return the person's name
	}
}
